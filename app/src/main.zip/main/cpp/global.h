extern float PRE[113][51];
extern float BACK[144][51];
extern float BOW[91][51];
extern float LUNGE[229][51];