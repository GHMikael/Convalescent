package com.baidu.paddle.lite.demo.yolo_detection;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.app.Activity;
import android.widget.*;

import com.baidu.paddle.lite.demo.common.CameraSurfaceView;
import com.baidu.paddle.lite.demo.common.Utils;

import java.util.ArrayList;

import java.util.Collections;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;


public class DoSportActivity extends Activity implements View.OnClickListener, CameraSurfaceView.OnTextureChangedListener, SeekBar.OnSeekBarChangeListener, Chronometer.OnChronometerTickListener, TextToSpeech.OnInitListener {
    CameraSurfaceView svPreview;
    String savedImagePath = "";
    Native predictor = new Native();
    boolean isStart;
    //上方指示器
    private long recordingTime;
    //主计时器
    private Chronometer time;
    private TextView count;
    private TextView score;
    //动作提示
    private TextView tip;
    //运行状态变量
    private boolean playing;
    private boolean pausing;
    //主要界面
    private View beforePlayingControl;
    private View playingControl;
    private int page;
    //提示工具
    private Toast myToast;
    private TextView overlayText;

    //动作计数
    private int actionCount;
    //动作 分数
    private float actionScore;

    private float aveScore;

    private int tmp;

    private int[] action_id;
    //动作代码
    private int pose;

    //计数选择器
    private int countSelector = 15;
    private TextView countShow;

    private Button btnPause;
    private Button btnStop;
    private Button btnRemake;

    private View btnSwitch;


    //分数记录
    private ArrayList<Float> scoreList;
    //定时器
//    private Timer mTimer;
//    private TimerTask mTimerTask;
//    private Handler mHandler;

    // TTS对象
    private TextToSpeech textToSpeech;


    @Override
    protected void onCreate(Bundle savedInstanceBundle) {
        super.onCreate(savedInstanceBundle);
        setContentView(R.layout.activity_dosport);
        //初始化设置
        initSettings();
        //初始化视图
        initView();
//        mTimer = new Timer();
//        mHandler = new Handler() {
//            @SuppressLint("HandlerLeak")
//            @Override
//            public void handleMessage(Message msg) {
//                switch (msg.what) {
//                    case 1:
//                        score.setText(actionCount != 0 ? String.valueOf(actionScore) : "0.0");
//                        count.setText(actionCount != 0 ? String.valueOf(actionCount) : "0.0");
//                        String color = null;
//                        if (actionCount != 0) {
//                            if(actionScore==0){
//                                score.setTextColor(Color.rgb(255, 255, 51));
//                            }else if (actionScore < 60) {
//                                score.setTextColor(Color.rgb(255, 66, 51));
//                            } else if (actionScore < 75) {
//                                score.setTextColor(Color.rgb(255, 165, 0));
//                            } else {
//                                score.setTextColor(Color.rgb(50, 205, 50));
//                            }
//                        }
//
//                        break;
//                }
//            }
//        };
//        mTimerTask = new TimerTask() {
//            @Override
//            public void run() {
////                Log.d("AndroidTimerDemo", "timer");
//                mHandler.sendEmptyMessage(1);
//            }
//        };
//        mTimer.schedule(mTimerTask, 0, 100);
        //检测用户是否授权了某个权限
        //如果未授权
        if (!checkAllPermissions()) {
            //申请权限
            System.out.println("111111111111");
            requestAllPermissions();
        }
        predictor.setAssetManager(getAssets());
    }


    @Override
    protected void onResume() {
        super.onResume();
        // Open camera until the permissions have been granted
        checkAndUpdateSettings();
        if (!checkAllPermissions()) {
            svPreview.disableCamera();
        }
        svPreview.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        svPreview.onPause();
    }

    @Override
    protected void onDestroy() {
        Log.d(String.valueOf(actionCount), "onDestroy:--------------------------- ");
        if (predictor != null) {
            predictor.reset();
            predictor.release();
        }
        if (textToSpeech != null) {
            textToSpeech.shutdown();
            textToSpeech.stop();
            super.onDestroy();
        }
    }

    /**
     * 初始化视图函数
     */
    @SuppressLint("WrongViewCast")
    private void initView() {
        playing = false;
        pausing = false;
        actionCount = 0;
        actionScore = 0;
        aveScore = 0;
        tmp = 0;
        recordingTime = 0;
        scoreList = new ArrayList();
        textToSpeech = new TextToSpeech(this, this);
        //获取上个 activity 传递的值 动作id
        pose = getIntent().getIntExtra("i", 1);
        //获取动作id
        action_id = getResources().getIntArray(R.array.pose_action_id);

        //获取动作名字 title
        String[] title = getResources().getStringArray(R.array.pose_name);
        //获取动作提示
        String[] tips = getResources().getStringArray(R.array.pose_tips);
        //摄像头表层
        //即打开摄像头显示
        svPreview = findViewById(R.id.sv_preview);
        //监听器
        svPreview.setOnTextureChangedListener(this);

        //时间设置 监听器
        SeekBar countPicker = findViewById(R.id.count_picker);
        countPicker.setOnSeekBarChangeListener(this);
        //时间 动作 分数 计算
        time = (Chronometer) findViewById(R.id.time_count);
//        time.setFormat("%s");
        count = findViewById(R.id.count_count);
        score = findViewById(R.id.score_count);
        //动作提示
        tip = findViewById(R.id.tip);

        beforePlayingControl = findViewById(R.id.before_playing_control);
        playingControl = findViewById(R.id.playing_control);

        //所有按钮
        Button btnStart = findViewById(R.id.start); // 1.确定 开始按钮
        btnPause = findViewById(R.id.pause);//2.暂停
        btnStop = findViewById(R.id.stop);//2.停止
        btnRemake = findViewById(R.id.remake);//3.重开
        btnSwitch = findViewById(R.id.btn_switch);
        View btnBack = findViewById(R.id.btn_back);//5.右上角返回上一级
        View btnHome = findViewById(R.id.btn_home);//5.右上角回到主页

        //每个按钮设置监听事件
        btnStart.setOnClickListener(this);
        btnPause.setOnClickListener(this);
        btnStop.setOnClickListener(this);
        btnRemake.setOnClickListener(this);
        btnSwitch.setOnClickListener(this);

        btnBack.setOnClickListener(this);
        btnHome.setOnClickListener(this);

        overlayText = findViewById(R.id.overlay_text);
        countShow = findViewById(R.id.count_show);
        TextView poseTitle = findViewById(R.id.pose_name);
        //设置动作名字
        poseTitle.setText(title[pose]);
        //动作提示
        tip.setText(tips[pose]);

        //选择演示视频  todo 修改成动态
        String uri = "android.resource://" + getPackageName() + "/";
        if (pose == 1) {
            uri += R.raw.pose_a_single;
//            svPreview.setBackgroundResource(R.drawable.bg_video_1);
        } else if (pose == 2) {
            uri += R.raw.pose_b_single;
//            svPreview.setBackgroundResource(R.drawable.bg_video_2);
        } else if (pose == 3) {
            uri += R.raw.pose_c_single;
//            svPreview.setBackgroundResource(R.drawable.bg_video_3);
        } else if (pose == 4) {
            uri += R.raw.pose_d_single;
//            svPreview.setBackgroundResource(R.drawable.bg_video_4);
        }
        //演示视频
        VideoView sampleVideo = findViewById(R.id.sample_video);
        sampleVideo.setVideoPath(uri);//视频路径
        sampleVideo.setVideoURI(Uri.parse(uri));
        // 设置视频监听器
        sampleVideo.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                mediaPlayer.setVolume(0f, 0f);//设置左右声道音量
                mediaPlayer.setLooping(true);//设置循环播放
            }
        });
        //视频播放
        sampleVideo.start();
        pageControl(1);
    }

    /**
     * 初始化 此activity 设置
     */
    public void initSettings() {
        //存储系统的配置信息
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.commit();
        SettingsActivity.resetSettings();
    }

    /**
     * 判单当前是第几页
     * 1.运动前
     * 2.运动中 摄像头打开
     * 3.摄像头打开
     *
     * @param page
     */
    private void pageControl(int page) {
        if (page == this.page) {
            return;
        } else {
            this.page = page;
        }
        if (page == 1) {
            playing = false;
            pausing = true;
            overlayText.setVisibility(View.GONE);
            beforePlayingControl.setVisibility(View.VISIBLE);
            playingControl.setVisibility(View.GONE);
            svPreview.setVisibility(View.GONE);
        } else if (page == 2) {
            playing = true;
            pausing = false;
            overlayText.setVisibility(View.VISIBLE);
            beforePlayingControl.setVisibility(View.GONE);
            playingControl.setVisibility(View.VISIBLE);
            svPreview.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 开始按钮
     * 倒计时等参数设置
     */
    private void start() {
        actionCount = 0;
        actionScore = 0;
        final String[] hint = {"训练开始!", "", "1", "", "2", "", "3", "", "准备好了吗?"};
        //
        //设置按钮失灵
        disableBtn(btnPause);
        disableBtn(btnStop);
        disableBtn(btnRemake);
        if(textToSpeech != null){
            textToSpeech.setPitch(1.5f);
            //设定语速 ，默认1.0正常语速
            textToSpeech.setSpeechRate(1.5f);
        }
        new CountDownTimer(9000, 1000) {
            //设置倒计时文字 间隔 1s
            @Override
            public void onTick(long l) {
                overlayText.setText(hint[(int) Math.floor(l / 1000)]);
                if (textToSpeech != null && !textToSpeech.isSpeaking()) {
                    //朗读，注意这里三个参数的added in API level 4   四个参数的added in API level 21
                    textToSpeech.speak(hint[(int) Math.floor(l / 1000)], TextToSpeech.QUEUE_FLUSH, null);
                }
            }
            //倒计时结束
            @Override
            public void onFinish() {
                overlayText.setText("");
                predictor.reset();
                actionCount = 0;
                actionScore = 0;
                tmp = 0;
                aveScore = 0;
                isStart=true;
                count.setText("0");
                score.setText("0.0");
                time.setBase(SystemClock.elapsedRealtime() - recordingTime);
                time.start();
                enableBtn(btnPause);
                enableBtn(btnStop);
                enableBtn(btnRemake);
            }
        }.start();
        pageControl(2);
    }

    /**
     * 按钮禁用
     */
    private void disableBtn(Button btn) {
        btn.setBackground(getResources().getDrawable(R.drawable.btn_disable));
        btn.setEnabled(false);


    }


    /**
     * 按钮启用
     */
    private void enableBtn(Button btn) {
        btn.setBackground(getResources().getDrawable(R.drawable.btn_selector));
        btn.setEnabled(true);
    }

    /**
     * 停止按钮
     */
    private void stop() {
        svPreview.releaseCamera();//释放摄像头资源
        recordingTime = 0;
        time.stop();
        textToSpeech.shutdown();
        textToSpeech.stop();
        aveScore = actionCount != 0 ? aveScore /= actionCount : 0;
        Intent i = new Intent(DoSportActivity.this, AfterSportActivity.class);

        float[] score_list=new float[scoreList.size()];
        for (int j=0;j<scoreList.size();j++){
            score_list[j]=scoreList.get(j);
        }
        i.putExtra("scoreList", score_list);
        Collections.sort(scoreList);
        i.putExtra("actionCount", String.valueOf(actionCount));
        i.putExtra("aveScore", String.valueOf(aveScore));
        i.putExtra("maxScore", String.valueOf(scoreList.size() != 0 ? scoreList.get(scoreList.size() - 1) : 0));
        i.putExtra("minScore", String.valueOf(scoreList.size() != 0 ? scoreList.get(0) : 0));
        i.putExtra("pose", action_id[pose]);
        i.putExtra("i", pose);


        actionCount=0;
        actionScore=0;
        isStart=false;
        finish();
        startActivity(i);
    }

    /**
     * 暂停按钮
     */
    private void pause() {
//        Button btnPause = findViewById(R.id.pause);
        if (playing) {
            pausing = !pausing;
            if (pausing) {
                disableBtn(btnStop);
                disableBtn(btnRemake);
                btnPause.setText("恢复");
                overlayText.setText("暂停中");
                time.stop();
                recordingTime = SystemClock.elapsedRealtime() - time.getBase();
                svPreview.releaseCamera();
            } else {
                enableBtn(btnStop);
                enableBtn(btnRemake);
                btnPause.setText("暂停");
                overlayText.setText("");
                time.setBase(SystemClock.elapsedRealtime() - recordingTime);
                time.start();
                svPreview.openCamera();
            }
        }
    }

    /**
     * 重开按钮
     */
    private void remake() {
        finish();
        actionCount = 0;
        actionScore = 0;
        tmp = 0;
        aveScore = 0;
        count.setText("0");
        score.setText("0.0");
        Intent i = new Intent(DoSportActivity.this, DoSportActivity.class);
        i.putExtra("pose", action_id[pose]);
        i.putExtra("i", pose);
        startActivity(i);
    }

    /**
     * 点击事件
     *
     * @param v
     */
    @Override
    public void onClick(View v) {
        Intent i;
        switch (v.getId()) {
            case R.id.start:
                start();
                break;
            case R.id.pause:
                pause();
                break;
            case R.id.stop:
                stop();
                break;
            case R.id.remake:
            case R.id.after_replay:
                remake();
                break;
            case R.id.after_home:
            case R.id.btn_home:
                i = new Intent(DoSportActivity.this, MainActivity.class);
                finish();
                startActivity(i);
                break;
            case R.id.btn_back:
                i = new Intent(DoSportActivity.this, SelectActivity.class);
                finish();
                startActivity(i);
                break;
            case R.id.btn_switch:
                svPreview.switchCamera();
                break;
        }
    }

    private void showToast(String text) {
        if (myToast == null) {
            myToast = Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT);
        } else {
            myToast.setText(text);
        }
        myToast.show();
    }

    /**
     * 滑动条设置
     * @param seekBar
     * @param progressValue
     * @param fromUser
     */
    @Override
    public void onProgressChanged(SeekBar seekBar, int progressValue, boolean fromUser) {
        countSelector = progressValue;
        countShow.setText(countSelector + "个");
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public boolean onTextureChanged(int inTextureId, int outTextureId, int textureWidth, int textureHeight) {
        synchronized (this) {
            savedImagePath = DoSportActivity.this.savedImagePath;
        }
        boolean modified = predictor.process(inTextureId, outTextureId, textureWidth, textureHeight, savedImagePath, action_id[pose], true);
        if (!savedImagePath.isEmpty()) {
            synchronized (this) {
                DoSportActivity.this.savedImagePath = "";
            }
        }

        int[] result = predictor.getActionCountAndScore();
        actionCount = result[0];
        actionScore = result[1];
        if (actionCount != 0 && tmp != actionCount && isStart) {
            aveScore += actionScore;
            //监听分数和计数 ，在主线程中修改UI
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    score.setText(actionCount != 0 ? String.valueOf(actionScore) : "0.0");
                    count.setText(actionCount != 0 ? String.valueOf(actionCount) : "0.0");
                    String color = null;
                    if (actionCount != 0) {
                        if(actionScore==0){
                            score.setTextColor(Color.rgb(255, 255, 51));
                        }else if (actionScore < 60) {
                            score.setTextColor(Color.rgb(255, 66, 51));
                        } else if (actionScore < 75) {
                            score.setTextColor(Color.rgb(255, 165, 0));
                        } else {
                            score.setTextColor(Color.rgb(50, 205, 50));
                        }
                    }
                }
            });
            if (textToSpeech != null && !textToSpeech.isSpeaking()) {
                // 设置音调，值越大声音越尖（女生），值越小则变成男声,1.0是常规
                textToSpeech.setPitch(1.5f);
                //设定语速 ，默认1.0正常语速
                textToSpeech.setSpeechRate(1);
                //朗读，注意这里三个参数的added in API level 4   四个参数的added in API level 21
                textToSpeech.speak(String.valueOf((int) actionScore), TextToSpeech.QUEUE_FLUSH, null);
            }
            scoreList.add(actionScore);
        }
        tmp = actionCount;
        if (actionCount == countSelector) {
            stop();
        }
        return modified;
    }

    public void checkAndUpdateSettings() {
        if (SettingsActivity.checkAndUpdateSettings(this)) {
            String realModelDir = getCacheDir() + "/" + SettingsActivity.modelDir;
            Utils.copyDirectoryFromAssets(this, SettingsActivity.modelDir, realModelDir);
            String realLabelPath = getCacheDir() + "/" + SettingsActivity.labelPath;
            Utils.copyFileFromAssets(this, SettingsActivity.labelPath, realLabelPath);
            predictor.init(
                    realModelDir,
                    realLabelPath,
                    SettingsActivity.cpuThreadNum,
                    SettingsActivity.cpuPowerMode,
                    SettingsActivity.inputWidth,
                    SettingsActivity.inputHeight,
                    SettingsActivity.inputMean,
                    SettingsActivity.inputStd,
                    SettingsActivity.scoreThreshold);
        }
    }

    /**
     * 权限申请结果回调函数
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults[0] != PackageManager.PERMISSION_GRANTED || grantResults[1] != PackageManager.PERMISSION_GRANTED) {
            new AlertDialog.Builder(DoSportActivity.this)
                    .setTitle("Permission denied")
                    .setMessage("Click to force quit the app, then open Settings->Apps & notifications->Target " +
                            "App->Permissions to grant all of the permissions.")
                    .setCancelable(false)
                    .setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            DoSportActivity.this.finish();
                        }
                    }).show();
        }
    }

    /**
     * 申请权限注册
     */
    private void requestAllPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA}, 0);
        System.out.println("权限申请");
    }

    /**
     * 权限检查
     * @return
     */
    private boolean checkAllPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }


    /**
     * 计时器回调函数
     * @param chronometer
     */
    @Override
    public void onChronometerTick(Chronometer chronometer) {
    }

    /**
     * TTS 初始化
     * @param status
     */
    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = textToSpeech.setLanguage(Locale.CHINA);
            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "数据丢失或不支持", Toast.LENGTH_SHORT).show();
            }
        }
    }
}