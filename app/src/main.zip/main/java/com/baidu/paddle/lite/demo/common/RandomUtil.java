package com.baidu.paddle.lite.demo.common;

/**
 * 生成随机6位数验证码
 */
public class RandomUtil {

	//  生成6位数随机验证码
	public static String getRandom() {
//		"q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m",
//				"A","W","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M",
		String[] letters = new String[] {
				"0","1","2","3","4","5","6","7","8","9"};
		String code ="";
		for (int i = 0; i < 6; i++) {
			code = code + letters[(int)Math.floor(Math.random()*letters.length)];
		}
		return code;
	}
}